* calibration folder: 
original images: left_pattern.jpg, right_pattern.jpg
images marked with selected points: left_pattern_mark.jpg, right_pattern_mark.jpg, 
2D point data: pts_2D_left.txt, pts_2D_right.txt
3D point data: pts_3D.txt

* faceimage folder:
original images: left_face.jpg, right_face.jpg
images marked with 30 facial feature points: left_facial_feature_points.jpg, right_facial_feature_points.jpg
2D point data: pts_left.txt, pts_right.txt